**EXECUTION DU CODE SOURCE :**



&nbsp;	**Ressources Requises : SDK .NET téléchargeable sur le site https://dotnet.microsoft.com.**

&nbsp;	**Mode d'exécution :** 

&nbsp;		Une fois les dépendances installées, ouvrez l'invite de commande directement dans ce dossier (L'invite de commande s'ouvre avec le chemin du dossier)

&nbsp;		Tapez la commande '**dotnet** run' (sans les ')

&nbsp;		Explorez.

