﻿namespace Hotel
{
    //Pour permettre l'utilisation d'une methode Presenter() dans les classes Chambre et Reservation
    interface Presentation
    {
        void Presenter();
    }

    class Chambre
    {
        //Attributs
        public int numero;
        public string type;
        public double prixNuit;
        public bool occupee;


        //Methodes
        public void Presenter(){
            Console.WriteLine("               CHAMBRES");
            Console.WriteLine("========================================");
            Console.WriteLine("NUMERO CHAMBRE :"+numero+"\n TYPE :"+type+"\n PRIX DE NUITS :"+prixNuit);
        }
        //Afficher la disponibilité de la chambre
        public void EstDisponible(){
            if (occupee == true)
            {
                Console.WriteLine("CHAMBRE NON DISPONIBLE");
            }
            else
            {
                Console.WriteLine("CHAMBRE DISPONIBLE");
            }
        }
        //Permet d'occuper une chambre
        public void OccuperChambre(){
            if (occupee == true)
            {
                Console.WriteLine("CHAMBRE OCCUPEE");
            }
            else
            {
                occupee = true;
                Console.WriteLine("VOUS OCCUPEE CETTE CHAMBRE : "+numero);
            }
        }
        //Permet de liberer une chambre
        public void LibererChambre(){
            if (occupee == true)
            {
                occupee = false;
                Console.WriteLine("VOUS AVEZ LIBERER LA CHAMBRE");
            }
            else
            {
                Console.WriteLine("CHAMBRE LIBRE");
            }
        }

    }


    class Reservation
    {
        //Attributs
        public string client;
        public Chambre chambre;
        public int nbNuits;
        public double montantTotal;


        //Methodes
        public void Presenter(){
            Console.WriteLine("            RESERVATIONS");
            Console.WriteLine("========================================");
            Console.WriteLine("NOM CLIENT :"+client+"\n NUMERO DE CHAMBRE :"+chambre.numero+"\n NOMBRE DE NUITS :"+nbNuits+"\n FRAIS :"+montantTotal);
        }
        //Permet de calculer le montant total d'une reservation
        public double CalculerMontant()
        {
            return nbNuits*chambre.prixNuit;
        }
    
    }
    

    class Mainclass
    {
        //Definition des tableaux de chambres et de reservations
        static Chambre[] chambres;
        static Reservation[] reservations;

        public static void Main()
        {
            //Instanciation de 20 chambres et de 12 reservations
            chambres = new Chambre[]
            {
                //chambres double
                new Chambre {numero = 1, type = "Double", prixNuit = 35000, occupee = true},
                new Chambre {numero = 2, type = "Double", prixNuit = 35000, occupee = true},
                new Chambre {numero = 3, type = "Double", prixNuit = 35000, occupee = true},
                new Chambre {numero = 4, type = "Double", prixNuit = 35000, occupee = false},
                new Chambre {numero = 5, type = "Double", prixNuit = 35000, occupee = false},
                new Chambre {numero = 6, type = "Double", prixNuit = 35000, occupee = false},
                new Chambre {numero = 7, type = "Double", prixNuit = 35000, occupee = false},
                new Chambre {numero = 8, type = "Double", prixNuit = 35000, occupee = true},
                new Chambre {numero = 9, type = "Double", prixNuit = 35000, occupee = true},
                new Chambre {numero = 10, type = "Double", prixNuit = 35000, occupee = true},
                //chambres simples
                new Chambre {numero = 11, type = "Simple", prixNuit = 7500, occupee = false},
                new Chambre {numero = 12, type = "Simple", prixNuit = 7500, occupee = false},
                new Chambre {numero = 13, type = "Simple", prixNuit = 7500, occupee = false},
                new Chambre {numero = 14, type = "Simple", prixNuit = 7500, occupee = false},
                new Chambre {numero = 15, type = "Simple", prixNuit = 7500, occupee = false},
                //chambres suites
                new Chambre {numero = 16, type = "Suite", prixNuit = 14000, occupee = true},
                new Chambre {numero = 17, type = "Suite", prixNuit = 14000, occupee = true},
                new Chambre {numero = 18, type = "Suite", prixNuit = 14000, occupee = true},
                new Chambre {numero = 19, type = "Suite", prixNuit = 14000, occupee = true},
                new Chambre {numero = 20, type = "Suite", prixNuit = 14000, occupee = true}
            };

            //Toutes les reservations
            reservations = new Reservation[]
            {
                new Reservation {client = "Jean Albertin", chambre = chambres[0], nbNuits= 3 },
                new Reservation {client = "PauLine Bahebeck", chambre = chambres[2], nbNuits= 2},
                new Reservation {client = "PAPA Zouzoua", chambre = chambres[3], nbNuits= 15},
                new Reservation {client = "Grace Deka", chambre = chambres[7], nbNuits= 3},
                new Reservation {client = "AMANDINE ROY", chambre = chambres[8], nbNuits= 2},
                new Reservation {client = "Celeste Victorien", chambre = chambres[9], nbNuits= 1},
                new Reservation {client = "Françoise Baumette", chambre = chambres[15], nbNuits= 3},
                new Reservation {client = "El Chapo", chambre = chambres[16], nbNuits= 3},
                new Reservation {client = "Jacky Chan de Koabang", chambre = chambres[17], nbNuits= 4},
                new Reservation {client = "Evelyne Song", chambre = chambres[18], nbNuits= 2},
                new Reservation {client = "Song Bahanack", chambre = chambres[19], nbNuits= 1}
            };
            //Calcul du montant total de chaque reservation
            foreach (Reservation i in reservations)
            {
                i.montantTotal = i.CalculerMontant();
                
            }
                
                //Menu Complet
                Console.WriteLine("====================================  MENU COMPLET ==================================== ");
                bool MenuActif = true;
                while (MenuActif) //tant que le menu est actif, on affiche les options et on traite les choix de l'utilisateur
                {
                    Console.WriteLine("============== MENU PRINCIPAL ==============");
                    Console.WriteLine("1. Afficher les chambres disponibles");
                    Console.WriteLine("2. Reserver une chambre");
                    Console.WriteLine("3. Checkout");
                    Console.WriteLine("4. Afficher toutes les reservations");
                    Console.WriteLine("5. Afficher les statistiques");
                    Console.WriteLine("6. Quitter");

                    //Lire le choix de l'utilisateur
                    string choix = Console.ReadLine();
                    switch (choix)
                {
                    case "1":
                    AfficherChambreDisponibles(); //Afficher les chambres disponibles en parcourant le tableau de chambres et en affichant celles qui ne sont pas occupées
                    break;

                    case "2":
                    ReserverChambre(); //Parcourir le tableau de chambres pour trouver la première chambre disponible, puis demander à l'utilisateur d'entrer les informations nécessaires pour la réservation (nom du client, nombre de nuits) et créer une nouvelle instance de Reservation avec ces informations. Ensuite, marquer la chambre comme occupée.
                    break;

                    case "3": //Demander à l'utilisateur d'entrer le numéro de chambre pour le checkout, puis parcourir le tableau de chambres pour trouver la chambre correspondante et la marquer comme libre. Ensuite, parcourir le tableau de reservations pour trouver la réservation correspondante et la supprimer (en la mettant à null).
                    Console.Write("Entrez le numéro de chambre pour le checkout : ");
                    if (int.TryParse(Console.ReadLine(), out int numChambre))
                    {
                        CheckOut(numChambre);
                    }
                    else
                    {
                        Console.WriteLine("Numéro invalide.");
                    }
                    break;

                    case "4":
                     AfficherToutesReservations(); //Parcourir le tableau de reservations et afficher les détails de chaque réservation (nom du client, numéro de chambre, nombre de nuits, montant total) en utilisant la méthode Presenter() de la classe Reservation.
                    break;

                    case "5": //Calculer et afficher les statistiques d'occupation et de recettes. Pour le taux d'occupation, parcourir le tableau de chambres pour compter le nombre de chambres occupées et le nombre total de chambres, puis calculer le taux d'occupation en divisant le nombre de chambres occupées par le nombre total de chambres et en multipliant par 100. Pour les recettes, parcourir le tableau de reservations pour calculer le montant total des réservations pour chaque type de chambre (double, simple, suite) en utilisant la méthode CalculerMontant() de la classe Reservation.
                    double TauxOccupation = 0;
                    double ChiffreAffairedouble = 0;
                    double ChiffreAffairesimple = 0;
                    double ChiffreAffairesuite = 0;
                    double Count = 0;
                    double TotalChambre = 0;
                    foreach (Chambre c in chambres)
                    {
                        
                        if (c.occupee)
                        {
                            Count += 1;
                        }
                        TotalChambre += 1;
                    }

                    foreach (Reservation v in reservations)
                    {
                        //pour le type de chambre
                        if (v.chambre.type == "Double")
                        {
                            ChiffreAffairedouble += v.montantTotal; 
                        }
                        if (v.chambre.type == "Simple")
                        {
                            ChiffreAffairesimple += v.montantTotal;
                        }
                        if (v.chambre.type == "Suite")
                        {
                            ChiffreAffairesuite += v.montantTotal;
                        }
                    }
                    //Afficher les recettes par type de chambre & le taux d'occupation
                    Console.WriteLine(" LES RECETTES PAR TYPES DE CHAMBRE : \n - Chambre Double :"+ChiffreAffairedouble+"\n - Chambre Simple :"+ChiffreAffairesimple+"\n -Chambre Suite :"+ChiffreAffairesuite);
                    TauxOccupation = (Count/TotalChambre)*100;
                    Console.WriteLine("Le taux d'occupation est de :"+TauxOccupation+"%");
                    break;

                    case "6": //Quitter le menu en mettant MenuActif à false
                    MenuActif = false;
                    Console.WriteLine("Merci d'avoir Souscrit à nos services !");
                    break;

                    default: Console.WriteLine("Choix invalide réessayez !"); //Afficher un message d'erreur pour les choix invalides et continuer à afficher le menu jusqu'à ce que l'utilisateur choisisse de quitter.
                    break;
                }
                }
                
            }
        public static void AfficherChambreDisponibles()
        {
            //Parcourir le tableau de chambres et afficher celles qui ne sont pas occupées en utilisant la méthode Presenter() de la classe Chambre.
            foreach (Chambre cd in chambres)
            {
                if (cd.occupee == false)
                {
                    Console.WriteLine("\n CHAMBRE DISPONIBLES \n ==========================================");
                    cd.Presenter();
                }
            }
        }
        public static void ReserverChambre(){
            //Parcourir le tableau de chambres pour trouver la première chambre disponible, puis demander à l'utilisateur d'entrer les informations nécessaires pour la réservation (nom du client, nombre de nuits) et créer une nouvelle instance de Reservation avec ces informations. Ensuite, marquer la chambre comme occupée.
            for (int k = 0; k < reservations.Length; k++)
            {
                if (reservations[k] == null)
                {
                    foreach (Chambre oc in chambres)
                    {
                        if (!oc.occupee)
                        {
                            Console.Write("Entrez le nom du client : ");
                            string nomClient = Console.ReadLine();
                            Console.Write("Entrez le nombre de nuits souhaité : ");
                            int nombreNuits = int.Parse(Console.ReadLine());
                            reservations[k] = new Reservation
                            {
                                client = nomClient,
                                chambre = oc,
                                nbNuits = nombreNuits,
                                montantTotal = oc.prixNuit * nombreNuits
                            };
                            oc.OccuperChambre();
                            return; 
                        }
                    }
                    break; 
                }
            }
        }
        public static void AfficherToutesReservations(){
            //Parcourir le tableau de reservations et afficher les détails de chaque réservation (nom du client, numéro de chambre, nombre de nuits, montant total) en utilisant la méthode Presenter() de la classe Reservation.
            foreach (Reservation r in reservations)
            {
                Console.WriteLine("\n ENSEMBLE DES RESERVATIONS \n ==========================================");
                r.Presenter();
            }
        }

        public static void CheckOut(int numChambre){
            //Demander à l'utilisateur d'entrer le numéro de chambre pour le checkout, puis parcourir le tableau de chambres pour trouver la chambre correspondante et la marquer comme libre. Ensuite, parcourir le tableau de reservations pour trouver la réservation correspondante et la supprimer (en la mettant à null).
            
            bool numValide = true;
            while (numValide)
            {
                    foreach (Chambre c in chambres)
                    {
                        if (c.numero == numChambre && c.occupee)
                        {
                            c.LibererChambre();
                        for (int i = 0; i < reservations.Length; i++)
                        {
                        if (reservations[i] != null && reservations[i].chambre.numero == numChambre)
                        {
                            reservations[i] = null;
                            break;
                        }
                        }
                        }
                    }
                    numValide = false;
                }
                

            }
        }
    }


